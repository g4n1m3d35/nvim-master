-- Configuración de opciones básicas
vim.opt.backup = false                          -- No crear archivos de backup
vim.opt.clipboard = 'unnamedplus'               -- Usar el portapapeles del sistema
vim.opt.cmdheight = 1                           -- Altura de la línea de comandos
vim.opt.completeopt = { 'menuone', 'noselect' } -- Opciones de autocompletado
vim.opt.conceallevel = 0                        -- No ocultar texto
vim.opt.fileencoding = 'utf-8'                  -- Codificación de archivos
vim.opt.hlsearch = true                         -- Resaltar búsquedas
vim.opt.ignorecase = true                       -- Ignorar mayúsculas en búsquedas
vim.opt.mouse = 'a'                             -- Habilitar mouse
vim.opt.pumheight = 10                          -- Altura del menú de autocompletado
vim.opt.showmode = false                        -- No mostrar modo actual (lo muestra la statusline)
vim.opt.smartcase = true                        -- Búsqueda sensible a mayúsculas si hay alguna
vim.opt.smartindent = true                      -- Indentación inteligente
vim.opt.splitbelow = true                       -- Dividir ventanas hacia abajo
vim.opt.splitright = true                       -- Dividir ventanas a la derecha
vim.opt.swapfile = false                        -- No crear archivos swap
vim.opt.termguicolors = true                    -- Habilitar colores de 24-bit
vim.opt.timeoutlen = 300                        -- Tiempo para combinaciones de teclas
vim.opt.undofile = true                         -- Habilitar undo persistente
vim.opt.updatetime = 300                        -- Tiempo para escribir el swap file
vim.opt.writebackup = false                     -- No hacer backup mientras se escribe
vim.opt.expandtab = true                        -- Usar espacios en lugar de tabs
vim.opt.shiftwidth = 2                          -- Número de espacios para indentación
vim.opt.tabstop = 2                             -- Número de espacios que un tab representa
vim.opt.cursorline = true                       -- Resaltar línea actual
vim.opt.number = true                           -- Mostrar números de línea
vim.opt.relativenumber = true                   -- Números de línea relativos
vim.opt.numberwidth = 4                         -- Ancho de la columna de números
vim.opt.signcolumn = 'yes'                      -- Mostrar columna de signos
vim.opt.wrap = false                            -- No envolver líneas
vim.opt.scrolloff = 8                           -- Líneas mínimas arriba/abajo del cursor
vim.opt.sidescrolloff = 8                       -- Columnas mínimas a los lados del cursor
vim.opt.guifont = 'Iosevka:h14'               -- Fuente para la interfaz gráfica

-- Configuración específica para Neovim
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1

-- Mejorar el rendimiento
vim.opt.lazyredraw = true
vim.opt.redrawtime = 1500
