local M = {}

-- Verificar salud de LSP
function M.check_lsp_health()
  local clients = vim.lsp.get_active_clients()
  if #clients == 0 then
    vim.notify("No hay clientes LSP activos", vim.log.levels.WARN)
    return
  end
   local messages = {}
  table.insert(messages, "═"..string.rep("═", 50).."═")
  table.insert(messages, "═"..string.format("%-50s", "Estado de LSP").."═")
  table.insert(messages, "═"..string.rep("═", 50).."═")
  
  for _, client in ipairs(clients) do
    local status = "OK"
    if client.is_stopped() then status = "DETENIDO" end
    
    local msg = string.format("│ %-20s │ %-10s │ %-15s │", 
      client.name, 
      status,
      client.config.root_dir or "N/A")
    table.insert(messages, msg)
  end
  
   table.insert(messages, "╘"..string.rep("═", 50).."╛")
  
  -- Mostrar en un buffer flotante
  local buf = vim.api.nvim_create_buf(false, true)
  vim.api.nvim_buf_set_lines(buf, 0, -1, true, messages)
  
  local width = 60
  local height = #messages + 2
  local row = math.floor((vim.o.lines - height) / 2)
  
   local col = math.floor((vim.o.columns - width) / 2)
  
  local opts = {
    relative = 'editor',
    width = width,
    height = height,
    row = row,
    col = col,
    style = 'minimal',
    border = 'rounded',
  }
  
  local win = vim.api.nvim_open_win(buf, true, opts)
  vim.api.nvim_win_set_option(win, 'winhl', 'Normal:NormalFloat')
  
  -- Cerrar con q
  vim.api.nvim_buf_set_keymap(buf, 'n', 'q', '<cmd>q<CR>', {noremap = true, silent = true})
end

-- Comandos de solución de problemas
vim.api.nvim_create_user_command('LSPHealth', M.check_lsp_health, {desc = 'Verificar estado de los servidores LSP'})

-- Manejo de errores comunes
local function handle_lsp_errors(err, method, result, client_id)
  if err then
  
     local client = vim.lsp.get_client_by_id(client_id)
    local msg = string.format("LSP Error [%s]: %s", client and client.name or "unknown", err.message)
    vim.notify(msg, vim.log.levels.ERROR)
    return true
  end
  return false
end

-- Sobrescribir manejadores LSP para mejor manejo de errores
vim.lsp.handlers['textDocument/hover'] = function(err, result, ctx, config)
  if handle_lsp_errors(err, 'textDocument/hover', result, ctx.client_id) then return end
  vim.lsp.handlers.hover(err, result, ctx, config)
end

vim.lsp.handlers['textDocument/signatureHelp'] = function(err, result, ctx, config)
  if handle_lsp_errors(err, 'textDocument/signatureHelp', result, ctx.client_id) then return end
  vim.lsp.handlers.signature_help(err, result, ctx, config)
end

-- Logs de depuración
function M.enable_lsp_logs()
  vim.lsp.set_log_level("debug")
  local log_path = vim.fn.stdpath("cache") .. "/lsp.log"
  vim.notify("Logs LSP activados en: " .. log_path, vim.log.levels.INFO)
  vim.fn.execute("edit " .. log_path)
  
 end

vim.api.nvim_create_user_command('LSPLogs', M.enable_lsp_logs, {desc = 'Activar logs de depuración para LSP'})

-- Reiniciar servidores LSP
function M.restart_lsp()
  local clients = vim.lsp.get_active_clients()
  if #clients == 0 then
    vim.notify("No hay clientes LSP activos para reiniciar", vim.log.levels.WARN)
    return
  end
  
  for _, client in ipairs(clients) do
    local client_id = client.id
    local client_name = client.name
    local buf = vim.api.nvim_get_current_buf()
    
    -- Detener el cliente actual
    vim.lsp.stop_client(client_id, true)
    
    -- Reiniciar con la misma configuración
    vim.defer_fn(function()
      local new_client = vim.lsp.start_client(client.config)
      if new_client then
        vim.lsp.buf_attach_client(buf, new_client)
        
   vim.notify(string.format("Servidor %s reiniciado", client_name), vim.log.levels.INFO)
      else
        vim.notify(string.format("Error al reiniciar %s", client_name), vim.log.levels.ERROR)
      end
    end, 500)
  end
end

vim.api.nvim_create_user_command('LSPRestart', M.restart_lsp, {desc = 'Reiniciar todos los servidores LSP activos'})

return M
        
