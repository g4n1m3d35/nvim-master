local opts = { noremap = true, silent = true }
vim.g.mapleader = " " -- Define the leader key
-- Mejor manejo de ventanas
vim.keymap.set('n', '<C-h>', '<C-w>h', opts)
vim.keymap.set('n', '<C-j>', '<C-w>j', opts)
vim.keymap.set('n', '<C-k>', '<C-w>k', opts)
vim.keymap.set('n', '<C-l>', '<C-w>l', opts)

-- Redimensionar ventanas con Shift + flechas
vim.keymap.set('n', '<S-Up>', ':resize -2<CR>', opts)
vim.keymap.set('n', '<S-Down>', ':resize +2<CR>', opts)
vim.keymap.set('n', '<S-Left>', ':vertical resize -2<CR>', opts)
vim.keymap.set('n', '<S-Right>', ':vertical resize +2<CR>', opts)

-- Movimiento entre buffers
vim.keymap.set('n', '<S-l>', ':bnext<CR>', opts)
vim.keymap.set('n', '<S-h>', ':bprevious<CR>', opts)

-- Mantener el cursor centrado al hacer scroll
vim.keymap.set('n', '<C-d>', '<C-d>zz', opts)
vim.keymap.set('n', '<C-u>', '<C-u>zz', opts)

-- Mejor indentación
vim.keymap.set('v', '<', '<gv', opts)
vim.keymap.set('v', '>', '>gv', opts)

-- Mover líneas seleccionadas en modo visual
vim.keymap.set('v', 'J', ":m '>+1<CR>gv=gv", opts)
vim.keymap.set('v', 'K', ":m '<-2<CR>gv=gv", opts)

-- Pegar sin sobrescribir el registro
vim.keymap.set('x', '<leader>p', '"_dP', opts)

-- Copiar al portapapeles del sistema
vim.keymap.set('n', '<leader>y', '"+y', opts)
vim.keymap.set('v', '<leader>y', '"+y', opts)
vim.keymap.set('n', '<leader>Y', '"+Y', opts)

-- Atajos útiles
vim.keymap.set('n', 'q', ':q<CR>', opts)
vim.keymap.set('n', 'w', ':w<CR>', opts)
--vim.keymap.set("n", "<leader>q", ":wq<CR>", { desc = "Save and exit from Neovim" })
-- vim.keymap.set('n', '<leader>e', ':Neotree source=filesystem reveal=true position=right<CR>', opts)

-- Configuración específica para Neovim
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1
vim.keymap.set('n', 'd', ':bdelete<CR>')


-- Mejorar el rendimiento
vim.opt.lazyredraw = true
vim.opt.redrawtime = 1500

-- Fzf-lua
--vim.keymap.set('n', '<leader>bf', ':FzfLua buffers<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua commands<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua complete_path<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua complete_file<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua complete_line<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua complete_bline<CR>')
--vim.keymap.set('n', '<leader>ff', ':FzfLua files<CR>')
--vim.keymap.set('n', '<leader>ff', ':FzfLua oldfiles<CR>')
--vim.keymap.set('n', '<leader>fq', ':FzfLua quickfix<CR>')
--vim.keymap.set('n', '<leader>ff', ':FzfLua quickfix_stack<CR>')
--vim.keymap.set('n', '<leader>ff', ':FzfLua loclist<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua loclist_stack<CR>')
--vim.keymap.set('n', '<leader>fl', ':FzfLua lines<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua blines<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua treesitter<CR>')
--vim.keymap.set('n', '<leader>tb', ':FzfLua tabs<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua args<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua grep<CR>')
--vim.keymap.set('n', '<leader>tg', ':FzfLua tags<CR>')
--vim.keymap.set('n', '<leader>gf', ':FzfLua git_files<CR>')
--vim.keymap.set('n', '<leader>gs', ':FzfLua git_status<CR>')
--vim.keymap.set('n', '<leader>gc', ':FzfLua git_commits<CR>')
--vim.keymap.set('n', '<leader>fg', ':FzfLua git_bcommits<CR>')
--vim.keymap.set('n', '<leader>bl', ':FzfLua git_blame<CR>')
--vim.keymap.set('n', '<leader>fg', ':FzfLua git_branches<CR>')
--vim.keymap.set('n', '<leader>fg', ':FzfLua git_tags<CR>')
--vim.keymap.set('n', '<leader>fg', ':FzfLua git_stash<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua lsp_references<CR>')
--vim.keymap.set('n', '<leader>fm', ':FzfLua manpages<CR>')
--vim.keymap.set('n', '<leader>fb', ':FzfLua resume<CR>')

-- NvimTree
 vim.keymap.set('n', '<leader>n', ':NvimTreeToggle source=filesystem reveal=true position=right<CR>', opts)
--vim.api.nvim_create_autocmd("BufEnter", {
--  nested = true,
--  callback = function()
--    if #vim.api.nvim_list_wins() == 1 and require("nvim-tree.utils").is_nvim_tree_buf() then
--      vim.cmd "quit"
--    end
--  end

-- })
 
-- Server config 
vim.keymap.set('n', '<S-p>', ':w<CR>: hor term python3 %<CR>') 
vim.keymap.set('n', '<S-j>', ':w <CR>: hor term java %')
vim.keymap.set('n', '<S-n>', ':w<CR>: hor term node %<CR>')
 
-- Configuracion de telescope

vim.keymap.set('n', '<leader>fb', ':Telescope buffers<CR>')
vim.keymap.set('n', '<leader>fc',':Telescope colorscheme<CR>')
vim.keymap.set('n', '<leader>ff',':Telescope find_files<CR>')
vim.keymap.set('n', '<leader>fg',':Telescope git_files<CR>')
vim.keymap.set('n', '<leader>gc',':Telescope git_commits<CR>')
vim.keymap.set('n', '<leader>gb',':Telescope git_branches<CR>')
vim.keymap.set('n', '<leader>gs',':Telescope git_status<CR>')
--vim.keymap.set('n', '<leader>fs',':Telescope git_stash<CR>')
vim.keymap.set('n', '<leader>fk',':Telescope keymaps<CR>')
vim.keymap.set('n', '<leader>fm',':Telescope man_pages<CR>')
--vim.keymap.set('n', '<leader>f',':Telescope treesitter<CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')
--vim.keymap.set('n', '<leader>f',':Telescope <CR>')

