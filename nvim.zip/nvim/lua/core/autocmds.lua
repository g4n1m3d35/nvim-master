local augroup = vim.api.nvim_create_augroup
local autocmd = vim.api.nvim_create_autocmd

-- Limpiar autocmds para evitar duplicados
augroup('MyAutoCmds', { clear = true })

-- Resaltar texto copiado
autocmd('TextYankPost', {
  group = 'MyAutoCmds',
  pattern = '*',
  callback = function()
    vim.highlight.on_yank({ higroup = 'IncSearch', timeout = 200 })
  end,
})

-- Formatear archivos específicos al guardar
autocmd('BufWritePre', {
  group = 'MyAutoCmds',
  pattern = { '*.lua', '*.py', '*.js', '*.ts', '*.json', '*.html', '*.css' },
  command = ':%s/\\s\\+$//e',
})

-- Deshabilitar auto-comentario en nueva línea
autocmd('BufEnter', {
  group = 'MyAutoCmds',
  pattern = '*',
  command = 'set fo-=c fo-=r fo-=o',
})

-- Ajustar configuración para tipos de archivo específicos
autocmd('FileType', {
  group = 'MyAutoCmds',
  pattern = { 'gitcommit', 'markdown' },
  command = 'setlocal wrap spell',
})

autocmd('FileType', {
  group = 'MyAutoCmds',
  pattern = { 'python' },
  command = 'setlocal shiftwidth=4 tabstop=4',
})
