local M = {}

function M.setup()
  -- Optimización para LSP
  vim.lsp.set_log_level("warn") -- Reducir logs en producción
  
  -- Configuración de debounce para LSP
  vim.lsp.handlers["textDocument/publishDiagnostics"] = vim.lsp.with(
    vim.lsp.diagnostic.on_publish_diagnostics, {
      -- Retraso para actualizar diagnósticos
      update_in_insert = false,
      debounce = 500,
    }
  )
  
   -- Configuración de debounce para cambios de texto
  vim.api.nvim_create_autocmd("TextChanged", {
    pattern = "*",
    callback = function()
      vim.lsp.util.buf_notify(0, "textDocument/didChange", {
        textDocument = vim.lsp.util.make_text_document_params(),
      })
    end,
    desc = "Notificar cambios a LSP con debounce",
    
    })
  
  -- Limitar memoria para ciertos servidores LSP
  local lsp_servers = require('lspconfig')
  local servers = {
    'tsserver',
    'pylsp',
    'jdtls',
    'clangd'
  }
  
  for _, server in ipairs(servers) do
    lsp_servers[server].setup({
      before_init = function(params)
        params.initializationOptions = params.initializationOptions or {}
        params.initializationOptions.memory = {
          max_workers = 4,
          max_memory_MB = 4096,
        }
      end
    })
  end
  
   -- Configuración específica para TypeScript
  lsp_servers.tsserver.setup({
    init_options = {
     tsserver = {
        maxTsServerMemory = 4096,
      }
    }
  })
  
  -- Configuración para proyectos grandes
  vim.api.nvim_create_autocmd("FileType", {
    pattern = { "typescript", "javascript", "python", "java", "go" },
    callback = function()
      -- Incrementar tiempo de espera para proyectos grandes
      vim.lsp.set_client_config({
        timeout = 30000, -- 30 segundos
      })
    end
  })
end

return M
  
