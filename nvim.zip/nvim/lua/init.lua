
--- Configurations

 -- =========================================================================================

 local vim = vim
 local Plug = vim.fn['plug#']

 vim.call('plug#begin')

-- Autocomplete
 Plug('hrsh7th/nvim-cmp')
 Plug('hrsh7th/cmp-buffer')
 Plug('hrsh7th/cmp-path')
 Plug('hrsh7th/cmp-cmdline')

-- Bar

 Plug('nvim-lualine/lualine.nvim')
 Plug('akinsho/bufferline.nvim', { ['tag'] = '*' })
 Plug('folke/noice.nvim')
 Plug('rcarriga/nvim-notify')
 Plug('chrisgrieser/nvim-dr-lsp')

-- Browser

 Plug('ray-x/web-tools.nvim')

-- Git

-- Plug('petertriho/cmp-git')
-- Plug('lewis6991/gitsigns')
-- Plug('tpope/vim-fugitive')

-- I.A
-- Plug ('carlos-algms/agentic.nvim')
-- Plug('milanglacier/minuet-ai.nvim')

-- Lsp

 Plug('neovim/nvim-lspconfig')
 Plug('hrsh7th/cmp-nvim-lsp')
 Plug('j-hui/fidget.nvim')
 Plug('onsails/lspkind.nvim')
 Plug('williamboman/mason.nvim')
 Plug('williamboman/mason-lspconfig.nvim')
 Plug('nvimdev/lspsaga.nvim')
 Plug ('ray-x/lsp_signature.nvim')

-- Search

-- Plug('ibhagwan/fzf-lua')
-- Plug('MagicDuck/grug-far.nvim')
-- Plug('ThePrimeagen/harpoon')
-- Plug('nvim-neo-tree/neo-tree.nvim')
 Plug('nvim-telescope/telescope.nvim', { ['tag'] = '0.1.8' })
 Plug('nvim-tree/nvim-tree.lua')
 Plug('nvim-lua/plenary.nvim')

-- Snippets

 Plug('saadparwaiz1/cmp_luasnip')
 Plug('L3MON4D3/LuaSnip', {['tag'] = 'v2.3.0', ['do'] = 'make install_jsregexp'})
 Plug('rafamadriz/friendly-snippets')

-- Sql

-- Plug ('tpope/vim-dadbod')
-- Plug ('kristijanhusak/vim-dadbod-ui')
-- Plug ('kristijanhusak/vim-dadbod-completion')

-- Syntax

 Plug('Kasama/nvim-custom-diagnostic-highlight')
-- Plug('zbirenbaum/copilot.lua')
 Plug('soulis-1256/eagle.nvim')
-- Plug('folke/flash.nvim')
 Plug('RRethy/vim-illuminate')
 Plug('mfussenegger/nvim-lint')
 Plug('nvimtools/none-ls.nvim')
 Plug('nvim-treesitter/nvim-treesitter', {['do'] = ':TSUpdate'})
 Plug('folke/trouble.nvim')
 Plug('MunifTanjim/nui.nvim')
 Plug('folke/which-key.nvim')

-- Themes
-- Plug('ellisonleao/gruvbox.nvim')
-- Plug('gbprod/nord.nvim')
-- Plug('AlexvZyl/nordic.nvim')
 Plug('navarasu/onedark.nvim')
-- Plug ('rmehri01/onenord.nvim')
-- Plug('craftzdog/solarized-osaka.nvim')
 Plug('folke/tokyonight.nvim')

-- Terminal

-- Plug('tribela/vim-transparent')
-- Plug('voldikss/vim-floaterm')

-- Tmux
 Plug('aserowy/tmux.nvim')
 Plug('benmills/vimux')

-- Type

 Plug('lukas-reineke/indent-blankline.nvim')
 Plug('windwp/nvim-autopairs')
 Plug('okuuva/auto-save.nvim', { ['tag'] = 'v1*' })
 Plug('windwp/nvim-ts-autotag')
 Plug('shoukoo/commentary.nvim')
-- Plug('antoinemadec/FixCursorHold.nvim')
-- Plug('echasnovski/mini.pairs', { 'branch': 'stable' })
-- Plug ('echasnovski/mini.nvim')
 Plug('kylechui/nvim-surround')
-- Plug ('echasnovski/mini.icons')
 Plug('nvim-tree/nvim-web-devicons')
 Plug('KabbAmine/zeavim.vim')

 vim.call('plug#end')

-- Colorschemes

-- vim.cmd('colorscheme gruvbox')
-- vim.cmd('colorscheme nord')
-- vim.cmd('colorscheme nordic')
 vim.cmd('colorscheme onedark')
-- vim.cmd('colorscheme onenord')
-- vim.cmd('colorscheme solarized-osaka')
-- vim.cmd('colorscheme tokyonight')

-- ======================================================================================================

