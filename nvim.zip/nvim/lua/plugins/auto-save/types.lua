--- @meta

--- @alias VerboseTriggerEvent { [1]: string, pattern?: string }
--- @alias TriggerEvent string | VerboseTriggerEvent
