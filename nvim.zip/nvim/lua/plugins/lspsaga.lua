local M = {}

function M.setup()
  local saga = require('lspsaga')
  
   saga.setup({
    -- Configuración de bordes
    border_style = "rounded",
    
    -- Configuración de diagnósticos
    diagnostic = {
      show_code_action = true,
      show_source = true,
      jump_num_shortcut = true,
      max_width = 0.7,
      max_height = 0.6,
      text_hl_follow = true,
      border_follow = true,
      extend_relatedInformation = true,
      keys = {
        exec_action = 'o',
        quit = 'q',
        go_action = 'g'
      },
    },
    
      -- Configuración de code action
    code_action = {
      num_shortcut = true,
      show_server_name = true,
      extend_gitsigns = true,
      
       only_in_cursor = true,
      keys = {
        quit = 'q',
        exec = '<CR>'
      },
    },
    
     -- Configuración de lightbulb
    lightbulb = {
      enable = true,
      sign = true,
      debounce = 10,
      sign_priority = 40,
      virtual_text = false,
      enable_in_insert = true,
    },
    
    -- Configuración de hover
    hover = {
      max_width = 0.8,
      max_height = 0.7,
      open_link = 'gx',
      open_browser = '!chrome',
    },
    
  -- Configuración de implementación
  
    implement = {
      enable = false,
      sign = true,
      virtual_text = false,
      priority = 20,
    },
    
    -- Configuración de definición
    definition = {
      width = 0.6,
      height = 0.5,
      save_pos = false,
      keys = {
        edit = '<CR>',
        vsplit = 'v',
        split = 's',
        tabe = 't',
        quit = 'q',
      },
    },
    
    -- Configuración de renombrar
    rename = {
      in_select = false,
      auto_save = false,
      project_max_width = 0.5,
       project_max_height = 0.5,
      keys = {
        quit = '<C-c>',
        exec = '<CR>',
        select = 'x',
      },
    },
    
    -- Configuración de símbolos
    symbol_in_winbar = {
      enable = true,
      separator = ' › ',
      hide_keyword = true,
      show_file = true,
      folder_level = 1,
      respect_root = true,
      color_mode = true,
    },
    
     -- Configuración de llamadas
    callhierarchy = {
      layout = 'float',
      keys = {
        edit = 'e',
        vsplit = 'v',
        split = 's',
        
          tabe = 't',
        close = '<C-c>',
        quit = 'q',
        shuttle = '[w',
        toggle_or_req = 'u',
      },
    },
    
     -- Configuración de outline
    outline = {
      win_position = 'right',
      win_width = 30,
      auto_preview = true,
      detail = true,
      auto_close = true,
      close_after_jump = false,
      layout = 'normal',
      max_height = 0.5,
      left_width = 0.3,
      keys = {
        toggle_or_jump = 'o',
        quit = 'q',
      },
    },
    
 -- Configuración de scroll
 
  scroll_preview = {
      scroll_down = '<C-f>',
      scroll_up = '<C-b>',
    },
    
    
   -- Configuración de notificaciones
    notify = {
      timeout = 3000,
    },
    
    -- Configuración de la barra de progreso
    progress = {
      max_size = 10,
    },
  })
  
  -- Mapeos personalizados para LSPSaga
  local opts = { noremap = true, silent = true }
  vim.keymap.set('n', 'gh', '<cmd>Lspsaga lsp_finder<CR>', opts)
  vim.keymap.set('n', 'gp', '<cmd>Lspsaga peek_definition<CR>', opts)
  vim.keymap.set('n', 'gr', '<cmd>Lspsaga rename<CR>', opts)
  vim.keymap.set('n', '<leader>ca', '<cmd>Lspsaga code_action<CR>', opts)
  vim.keymap.set('v', '<leader>ca', '<cmd><C-U>Lspsaga range_code_action<CR>', opts)
  vim.keymap.set('n', '[e', '<cmd>Lspsaga diagnostic_jump_prev<CR>', opts)
  vim.keymap.set('n', ']e', '<cmd>Lspsaga diagnostic_jump_next<CR>', opts)
  vim.keymap.set('n', '<leader>o', '<cmd>Lspsaga outline<CR>', opts)
  
    vim.keymap.set('n', '<leader>ci', '<cmd>Lspsaga incoming_calls<CR>', opts)
  vim.keymap.set('n', '<leader>co', '<cmd>Lspsaga outgoing_calls<CR>', opts)
end

return M

