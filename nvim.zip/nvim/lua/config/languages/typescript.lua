local M = {}

function M.setup()
  local lspconfig = require('lspconfig')
  local util = require('lspconfig/util')
  
  lspconfig.ts_ls.setup({
--    on_attach = require('plugins.lsp').on_attach,
--    capabilities = require('plugins.lsp').capabilities,
    root_dir = util.root_pattern("package.json", "tsconfig.json", "jsconfig.json", ".git"),
    init_options = {
      preferences = {
        importModuleSpecifierPreference = "relative",
        includeInlayParameterNameHints = "all",
        includeInlayParameterNameHintsWhenArgumentMatchesName = true,
        includeInlayFunctionParameterTypeHints = true,
        includeInlayVariableTypeHints = true,
        includeInlayPropertyDeclarationTypeHints = true,
        includeInlayFunctionLikeReturnTypeHints = true,
        includeInlayEnumMemberValueHints = true,
      },
      tsserver = {
        maxTsServerMemory = 4096,
      },
      plugins = {
        {
 name = "@vue/typescript-plugin",
          location = "/path/to/vue/typescript/plugin",
          languages = { "vue" }
        }
      }
    },
    filetypes = { "typescript", "javascript", "typescriptreact", "javascriptreact", "vue" },
    settings = {
      completions = {
        completeFunctionCalls = true
      },
      typescript = {
        inlayHints = {
          includeInlayParameterNameHints = "all",
          includeInlayParameterNameHintsWhenArgumentMatchesName = false,
          includeInlayFunctionParameterTypeHints = true,
          includeInlayVariableTypeHints = true,
          includeInlayPropertyDeclarationTypeHints = true,
          includeInlayFunctionLikeReturnTypeHints = true,
          includeInlayEnumMemberValueHints = true,
        },
        suggest = {
          autoImports = true,
        },
        format = {
          indentSize = vim.bo.shiftwidth,
          
        convertTabsToSpaces = vim.bo.expandtab,
          tabSize = vim.bo.tabstop,
        },
      },
      javascript = {
        inlayHints = {
          includeInlayParameterNameHints = "all",
          includeInlayParameterNameHintsWhenArgumentMatchesName = false,
          includeInlayFunctionParameterTypeHints = true,
          includeInlayVariableTypeHints = true,
          includeInlayPropertyDeclarationTypeHints = true,
          includeInlayFunctionLikeReturnTypeHints = true,
          includeInlayEnumMemberValueHints = true,
        },
        suggest = {
          autoImports = true,
        },
        format = {
          indentSize = vim.bo.shiftwidth,
          convertTabsToSpaces = vim.bo.expandtab,
          tabSize = vim.bo.tabstop,
        },
      },
    },
  })
    
 -- Configuración para evitar conflicto entre tsserver y denols
local is_node_project = util.root_pattern("package.json")
  
local function start_tsserver()
  local root_files = {'package.json', 'tsconfig.json', 'jsconfig.json'}
  local paths = vim.fs.find(root_files, {stop = vim.env.HOME})
  local root_dir = vim.fs.dirname(paths[1])

  if root_dir == nil then
    return
  end

  vim.lsp.start({
    name = 'tsserver',
    cmd = {'typescript-language-server', '--stdio'},
    root_dir = root_dir,
    init_options = {hostInfo = 'neovim'},
  })
end

vim.api.nvim_create_autocmd('FileType', {
  pattern = {'javascript', 'javascriptreact', 'javascript.jsx', 'typescript', 'typescriptreact', 'typescript.tsx'},
  desc = 'Iniciar tsserver',
  callback = start_tsserver,
})

end
return M
         
