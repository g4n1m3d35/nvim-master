local M = {}

function M.setup()
  local lspconfig = require('lspconfig')
  local util = require('lspconfig/util')
  
  -- Configuración para pyright
  lspconfig.pyright.setup({
--    on_attach = require('plugins.lsp').on_attach,
--    capabilities = require('plugins.lsp').capabilities,
    root_dir = function(fname)
      return util.root_pattern('.git', 'setup.py', 'setup.cfg', 'pyproject.toml', 'requirements.txt')(fname)
        or util.path.dirname(fname)
    end,
    settings = {
      python = {
        analysis = {
          autoSearchPaths = true,
          useLibraryCodeForTypes = true,
          diagnosticMode = "workspace",
          typeCheckingMode = "basic",
          stubPath = vim.fn.stdpath('data') .. '/stubs',
          diagnosticSeverityOverrides = {
            reportUnusedVariable = "warning",
            reportUnusedImport = "warning",
            reportUnusedClass = "warning",
              reportUnusedFunction = "warning",
            reportUnusedArgument = "warning",
            reportUnusedCallResult = "warning",
            reportDuplicateImport = "error",
            reportPrivateUsage = "error",
            reportMissingImports = "error",
            reportUndefinedVariable = "error",
            reportGeneralTypeIssues = "error",
          },
          inlayHints = {
            variableTypes = true,
            functionReturnTypes = true,
            parameterNames = true,
            parameterTypes = true,
          },
        },
        formatting = {
          provider = "black",
          blackPath = "black",
          args = { "--line-length", "88", "--quiet" },
        },
        linting = {
          pylintEnabled = true,
          flake8Enabled = false,
          mypyEnabled = false,
          pycodestyleEnabled = false,
          pydocstyleEnabled = false,
          banditEnabled = false,
          ruffEnabled = false,
        },
      },
    },
  })
  
  -- Configuración opcional para pylsp
  lspconfig.pylsp.setup({
--    on_attach = require('plugins.lsp').on_attach,
--    capabilities = require('plugins.lsp').capabilities,
    settings = {
      pylsp = {
        configurationSources = { "flake8", "pycodestyle", "pylint" },
        plugins = {
          pycodestyle = {
            enabled = true,
            maxLineLength = 88,
            ignore = { "W391" },
          },
          pylint = {
            enabled = true,
            args = { "--disable=C0114,C0115,C0116,R0903" },
          },
          flake8 = {
          enabled = false,
            maxLineLength = 88,
          },
          yapf = {
            enabled = false,
          },
          autopep8 = {
            enabled = false,
          },
          mccabe = {
            enabled = false,
          },
          pyflakes = {
            enabled = false,
          },
          rope_autoimport = {
            enabled = true,
            memory = false,
          },
          rope_completion = {
            enabled = true,
          },
          jedi_completion = {
            fuzzy = true,
          },
          jedi_definition = {
          follow_imports = true,
            follow_builtin_imports = true,
          },
          jedi_hover = {
            enable = true,
          },
          jedi_references = {
            enable = true,
          },
          jedi_signature_help = {
            enable = true,
          },
          jedi_symbols = {
            enable = true,
            all_scopes = true,
          },
          preload = {
            enabled = true,
          },
        },
      },
    },
  })
  
    -- Configuración para proyectos con múltiples entornos
  local venv_path = os.getenv('VIRTUAL_ENV')
  if venv_path then
    lspconfig.pyright.setup({
      before_init = function(_, config)
        config.settings.python.pythonPath = venv_path .. '/bin/python'
      end
    })
  end
  
  end

return M

