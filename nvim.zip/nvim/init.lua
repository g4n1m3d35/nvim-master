local present, impatient = pcall(require, "impatient")

-- Cargar configuración básica
require('core.options')
require('core.keymaps')
require('core.autocmds')
require('core.performance')
require('core.troubleshooting')
require('init')
require('plugins.autopairs')
require('plugins.auto-save')
require('plugins.buffer')
require('plugins.bufferline')
require('plugins.cmp')
require('plugins.cmp-cmdline')
require('plugins.cmp_luasnip')
require('plugins.commentary')
require('plugins.eagle')
require('plugins.illuminate')
require ('plugins.lspconfig')
--require('plugins.lsp_signature')
require('plugins.lspsaga')
require('plugins.lualine')
require('plugins.luasnip')
require('plugins.mason')
require('plugins.mason-lspconfig')
require('plugins.noice')
require('plugins.web-tools')
--require('plugins.minuet')
require('plugins.notify')
require('plugins.nvim-tree')
--require('onenord')
require('plugins.telescope')
--require('plugins.tokionight')
require('plugins.trouble')
require('plugins.which-key')
require('plugins.web-devicons')


-- Configuración específica por lenguaje

require('config.languages.typescript').setup()
require('config.languages.python').setup()
-- Añadir más configuraciones de lenguaje según sea necesario

-- Inicialización final

vim.defer_fn(function()
  vim.notify("Configuración LSP cargada correctamente", vim.log.levels.INFO, { title = "LSP Status" })
end, 1000)

-- ==================================================================================

