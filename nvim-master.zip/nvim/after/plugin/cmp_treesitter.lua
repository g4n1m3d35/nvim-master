require'cmp'.register_source('treesitter', require'cmp_treesitter'.new())
